
import Foundation
import UIKit


public func add (a:Int,b:Int) -> Int {
    return a + b
}
public func sub (a:Int,b:Int) -> Int {
    return a - b
}
public func divide (a:Int,b:Int) -> Int {
    return a / b
}

